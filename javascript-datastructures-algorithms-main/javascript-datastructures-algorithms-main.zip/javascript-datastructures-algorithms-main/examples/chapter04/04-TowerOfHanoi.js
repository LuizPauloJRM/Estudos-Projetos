const { hanoiStack } = PacktDataStructuresAlgorithms;
const { hanoi } = PacktDataStructuresAlgorithms;

console.log(hanoiStack(3));

console.log(hanoi(3, 'source', 'helper', 'dest'));
