const { ratInAMaze } = PacktDataStructuresAlgorithms;

const maze = [
  [1, 0, 0, 0],
  [1, 1, 1, 1],
  [0, 0, 1, 0],
  [0, 1, 1, 1]
];

console.log(ratInAMaze(maze));
