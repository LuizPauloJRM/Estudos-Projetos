// @ts-check
/* eslint-disable */

console.log('**** for example ****');
/* for - example */
for (var i = 0; i < 10; i++) {
  console.log(i);
}

console.log('**** while example ****');
/* while - example */
var i = 0;
while (i < 10) {
  console.log(i);
  i++;
}

console.log('**** do-while example ****');
/* do-while - example */
var i = 0;
do {
  console.log(i);
  i++;
} while (i < 10);
