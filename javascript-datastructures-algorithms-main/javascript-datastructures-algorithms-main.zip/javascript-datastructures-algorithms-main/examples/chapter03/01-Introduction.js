// @ts-check

const averageTempJan = 31.9;
const averageTempFeb = 35.3;
const averageTempMar = 42.4;
const averageTempApr = 52;
const averageTempMay = 60.8;

const averageTemp = [];
averageTemp[0] = 31.9;
averageTemp[1] = 35.3;
averageTemp[2] = 42.4;
averageTemp[3] = 52;
averageTemp[4] = 60.8;

console.log('averageTempJan', averageTempJan);
console.log('averageTempFeb', averageTempFeb);
console.log('averageTempMar', averageTempMar);
console.log('averageTempApr', averageTempApr);
console.log('averageTempMay', averageTempMay);

console.log('averageTemp[0]', averageTemp[0]);
console.log('averageTemp[1]', averageTemp[1]);
console.log('averageTemp[2]', averageTemp[2]);
console.log('averageTemp[3]', averageTemp[3]);
console.log('averageTemp[4]', averageTemp[4]);
